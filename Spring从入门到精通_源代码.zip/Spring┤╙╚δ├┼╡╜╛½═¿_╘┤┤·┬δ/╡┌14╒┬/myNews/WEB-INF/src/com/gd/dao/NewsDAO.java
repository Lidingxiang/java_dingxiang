package com.gd.dao;

import java.util.List;

import com.gd.po.*;

public interface NewsDAO {
    public abstract void createNews(New news);
	public abstract void updateNews(New news);
	public abstract void deleteNews(New news);
    public abstract New queryNews(Integer id);
	public abstract List getNewsByType(Integer id);
}
