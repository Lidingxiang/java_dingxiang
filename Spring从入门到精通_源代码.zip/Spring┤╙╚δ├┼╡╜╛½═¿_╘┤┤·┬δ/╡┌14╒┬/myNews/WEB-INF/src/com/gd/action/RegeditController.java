/*
 * Created on 2006-4-14
 * TODO
 * author:gf
 */
package com.gd.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.gd.dao.NewsTypeDAO;
import com.gd.service.Regedit;
import com.gd.vo.NewsType;
import com.gd.vo.User;

public class RegeditController extends SimpleFormController {
	private Logger logger = Logger.getLogger(this.getClass().getName());  
	private Regedit regedit;
  	public Regedit getRegedit () {
    		return regedit;
  	}
 	public void setRegedit (Regedit regedit) { 
    		this.regedit = regedit;
  	}
	public ModelAndView onSubmit(HttpServletRequest req, HttpServletResponse res,Object command, BindException errors) throws Exception { 
		 HttpSession session = req.getSession(true);
		 
		 User user = (User)command;
         Map model = errors.getModel();
		 getRegedit().saveUser(user);
		 List newsTypes = getNewsTypeDAO().queryNewsType();
		 model.put("newsTypes", newsTypes);
	     model.put("user", user); 
		 session.setAttribute("user", user);
         return new ModelAndView(getSuccessView(), model); 
    } 
	private NewsTypeDAO newsTypeDAO;
  	public NewsTypeDAO getNewsTypeDAO () {
    		return newsTypeDAO;
  	}
 	public void setNewsTypeDAO (NewsTypeDAO newsTypeDAO) { 
    		this.newsTypeDAO = newsTypeDAO;
  	}
}
