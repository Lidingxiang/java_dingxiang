/*
 * Created on 2006-6-7
 * TODO
 * author:gf
 */
package com.gd.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class News {
public int getId(){
        return id;
    }
    public void setId(int id){
         this.id = id;
    }
public String getMsg(){ 
return msg; 
}
public void setMsg(String msg){ 
this.msg = msg; 
}
public String getHead(){ 
return head; 
}
public void setHead(String head){ 
this.head = head; 
}
public String getContent(){ 
return content; 
}
public void setContent(String content){ 
this.content = content; 
}
public Date getDate(){ 
return date; 
}
public void setDate(Date date){ 
this.date = date; 
}
    public List getNewsByType(int id) {
		
		return new ArrayList();
    }
    public void saveNews() {
}
private int id;
    private String msg;
    private String head;
    private String content;
    private Date date;
    /**
     * @clientCardinality n
     * @supplierCardinality 1 
     */
    private NewsType lnkNewsType;
    /**
     * @clientCardinality n
     * @supplierCardinality 1 
     */
    private User lnkUser;
	
	public User getLnkUser(){ 
		return lnkUser; 
	}
	public void setLnkUser(User lnkUser){ 
		this.lnkUser = lnkUser; 
	}
	
	public NewsType getLnkNewsType(){ 
		return lnkNewsType; 
	}
	public void setLnkNewsType(NewsType lnkNewsType){ 
		this.lnkNewsType = lnkNewsType; 
	}
}

