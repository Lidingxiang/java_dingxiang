package com.gd.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;

import com.gd.dao.NewsTypeDAO;
import com.gd.po.Newstype;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class NewsTypeDAOImpl extends HibernateDaoSupport implements NewsTypeDAO {
	private Logger logger = Logger.getLogger(this.getClass().getName()); 
	
	private SessionFactory sessionFactory;
	private String hql = "from Newstype ";
	
	public void createNewsType(Newstype newsType) {
		this.getHibernateTemplate().save(newsType);
	}
	public void updateNewsType(Newstype newsType) {
		this.getHibernateTemplate().update(newsType);
	}
	public void deleteNewsType(Newstype newsType) {
		this.getHibernateTemplate().delete(newsType);
	}
	public List queryNewsType(){
		List newsTypeList;
		if (this.getHibernateTemplate().find(hql) == null )
			newsTypeList = new ArrayList();
		else 
			newsTypeList = this.getHibernateTemplate().find(hql);
		return newsTypeList;
	}
}