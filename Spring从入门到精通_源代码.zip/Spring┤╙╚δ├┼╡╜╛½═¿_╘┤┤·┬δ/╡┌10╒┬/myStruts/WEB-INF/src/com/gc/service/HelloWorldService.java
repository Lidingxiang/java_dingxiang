/*
 * Created on 2006-5-15
 * TODO
 * author:gf
 */
package com.gc.service;

import com.gc.action.HelloWorld;

public interface  HelloWorldService {
	public abstract String addMsg(HelloWorld helloWorld);
}
