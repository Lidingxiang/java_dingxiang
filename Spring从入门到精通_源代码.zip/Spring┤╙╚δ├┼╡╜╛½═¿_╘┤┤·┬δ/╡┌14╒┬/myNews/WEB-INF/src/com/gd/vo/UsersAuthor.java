/*
 * Created on 2006-6-7
 * TODO
 * author:gf
 */
package com.gd.vo;
public class UsersAuthor {
    public void setUsersAuthor(User lnkUser, int power) {
          lnkUser = lnkUser;
		power = power;
    }
    public int getAuthorByUser(User lnkUser) {
        return power;
    }
    public UsersAuthor(User lnkUser, int power) {
        lnkUser = lnkUser;
		power = power;
    }
    private int power;
    /**
     * @clientCardinality 1
     * @supplierCardinality 0.n 
     */
    private User lnkUser;
}

