package com.gd.po;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
public class Newstype implements Serializable {

    /** identifier field */
    private Integer id;

    /** persistent field */
    private String type;

    /** full constructor */
    public Newstype(String type) {
        this.type = type;
    }

    /** default constructor */
    public Newstype() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

}
