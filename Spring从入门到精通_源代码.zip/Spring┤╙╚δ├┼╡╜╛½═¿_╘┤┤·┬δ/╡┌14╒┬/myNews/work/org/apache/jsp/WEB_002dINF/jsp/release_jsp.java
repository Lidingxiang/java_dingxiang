package org.apache.jsp.WEB_002dINF.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.List;
import com.gd.util.*;
import com.gd.vo.User;
import com.gd.po.Newstype;

public final class release_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GBK");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"\r\n");
      out.write("\"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\">\r\n");
      out.write("<title>发布新闻画面</title>\r\n");
      out.write("<style type=\"text/css\">\r\n");
      out.write("<!--\r\n");
      out.write(".style1 {\r\n");
      out.write("\tfont-size: large;\r\n");
      out.write("\tfont-weight: bold;\r\n");
      out.write("}\r\n");
      out.write("-->\r\n");
      out.write("</style>\r\n");
      out.write("\r\n");
      out.write("</head>\r\n");
 
List newsTypes = (List)request.getAttribute("newsTypes");
User user = (User)request.getAttribute("user");

      out.write("\r\n");
      out.write("<body>\r\n");
      out.write("<form name=\"form1\" method=\"post\" action=\"/myNews/release.do\">\r\n");
      out.write("  <table width=\"100%\" height=\"160\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\">\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td height=\"17\" colspan=\"2\"><div align=\"center\" class=\"style1\">发布新闻</div></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td width=\"126\" height=\"19\"><strong>新闻标题</strong></td>\r\n");
      out.write("      <td width=\"560\"><input name=\"head\" type=\"text\" size=\"100%\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td height=\"73\"><strong>新闻内容</strong></td>\r\n");
      out.write("      <td><p>\r\n");
      out.write("        <textarea name=\"content\" cols=\"100%\" rows=\"30\"></textarea>\r\n");
      out.write("      </p>\r\n");
      out.write("      </td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td height=\"19\" colspan=\"2\"><strong>发布时间：</strong>");
      out.print(NewsUtil.getCurrentDate());
      out.write("<strong>发布人</strong>：");
      out.print(user.getUsername());
      out.write(" <strong>新闻类别</strong>：\r\n");
      out.write("        <select name=\"newsType\">\r\n");
      out.write("          ");

          	   for (int i = 0; newsTypes != null && i < newsTypes.size(); i++) {
				   Newstype newsType = (Newstype)newsTypes.get(i);
          
      out.write("\r\n");
      out.write("          <option value = '");
      out.print(newsType.getId());
      out.write('\'');
      out.write('>');
      out.print(newsType.getType());
      out.write("</option>\r\n");
      out.write("          ");
}
      out.write("\r\n");
      out.write("        </select></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td height=\"18\">&nbsp;</td>\r\n");
      out.write("      <td><input type=\"submit\" name=\"insert\" value=\"提交\">\r\n");
      out.write("      <input type=\"submit\" name=\"update\" value=\"修改\">\r\n");
      out.write("      <input type=\"submit\" name=\"delete\" value=\"删除\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("  </table>\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
