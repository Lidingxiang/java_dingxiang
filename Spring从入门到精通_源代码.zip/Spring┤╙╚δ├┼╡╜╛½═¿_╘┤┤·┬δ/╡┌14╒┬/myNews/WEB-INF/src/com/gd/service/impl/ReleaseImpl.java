/*
 * Created on 2006-5-15
 * TODO
 * author:gf
 */
package com.gd.service.impl;

import com.gd.dao.NewsDAO;
import com.gd.dao.UserDAO;
import com.gd.service.Login;
import com.gd.service.Release;
import com.gd.vo.News;
import com.gd.vo.User;

public class ReleaseImpl implements Release {
	private NewsDAO newsDao ;
	public void saveNews(News news) {
		com.gd.po.New newpo  = new com.gd.po.New();
		newpo.setHead(news.getHead());
		newpo.setContent(news.getContent());
		newpo.setIssueuser(news.getLnkUser().getUsername());
		newpo.setIssuedate(news.getDate());
		newpo.setNewstype(news.getLnkNewsType().getId());
		newsDao.createNews(newpo);
	}
	public void updateNews(News news) {
		com.gd.po.New newpo  = new com.gd.po.New();
		newpo.setHead(news.getHead());
		newpo.setContent(news.getContent());
		newpo.setIssueuser(news.getLnkUser().getUsername());
		newpo.setIssuedate(news.getDate());
		newpo.setNewstype(news.getLnkNewsType().getId());
		newsDao.updateNews(newpo);
	}
	public void deleteNews(News news) {
		com.gd.po.New newpo  = new com.gd.po.New();
		newpo.setHead(news.getHead());
		newpo.setContent(news.getContent());
		newpo.setIssueuser(news.getLnkUser().getUsername());
		newpo.setIssuedate(news.getDate());
		newpo.setNewstype(news.getLnkNewsType().getId());
		newsDao.deleteNews(newpo);
	}

	public News queryNews(int id) {
		News news = new News();
		news.setHead(newsDao.queryNews(id).getHead());
		news.setContent(newsDao.queryNews(id).getContent());
		news.setLnkUser(getLogin().queryUser(newsDao.queryNews(id).getIssueuser()));
		news.setDate(newsDao.queryNews(id).getIssuedate());
		return news;
	}
	
	public void setNewsDao (NewsDAO newsDao) {
		this.newsDao = newsDao;
	}
	public NewsDAO getNewsDao () {
		return this.newsDao;
	}
	
	private Login login;
  	public Login getLogin () {
    		return login;
  	}
 	public void setLogin (Login login) { 
    		this.login = login;
  	}
}
