/*
 * Created on 2006-5-15
 * TODO
 * author:gf
 */
package com.gc.service;

import com.gc.vo.User;

public interface Regedit {
	public abstract void saveUser(User user);
}
