/*
 * Created on 2006-5-15
 * TODO
 * author:gf
 */
package com.gd.service.impl;

import com.gd.dao.UserDAO;
import com.gd.service.Login;
import com.gd.vo.User;

public class LoginImpl implements Login {
	private UserDAO userDAO ;
	public User queryUser(String username) {
		User user = new User();
		user.setUsername(userDAO.queryUser(username).getUsername());
		user.setPassword1(userDAO.queryUser(username).getPassword());
		return user;
	}
	
	public void setUserDAO (UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	public UserDAO getUserDAO () {
		return this.userDAO;
	}
}
