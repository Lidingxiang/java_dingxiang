/*
 * Created on 2006-5-15
 * TODO
 * author:gf
 */
package com.gd.service;

import com.gd.vo.User;

public interface Regedit {
	public abstract void saveUser(User user);
	public abstract void deleteUser(User user);
	public abstract void updateUser(User user);
}
