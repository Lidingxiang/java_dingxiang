/*
 * Created on 2006-2-28
 * TODO
 * author:gf
 */
package com.gc.impl;

import org.apache.log4j.Level;

public interface TimeBookInterface {
	public void doAuditing(String name);
	public void doCheck(String name);
}
