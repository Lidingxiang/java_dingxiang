/*
 * Created on 2006-2-9
 * TODO
 * author:gf
 */
package com.gc.action;

public class Business {
	//private DataBase db = new DataBase();
	
	public void getData() {
		//db.getDataFromDataBase();
	}
}
