/*
 * Created on 2006-6-7
 * TODO
 * author:gf
 */
package com.gd.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class NewsUtil {
	/**
	 * �õ���ǰϵͳ����,��ʽ��yyyy-mm-dd
	 * 
	 * @return String
	 */
	public static String getCurrentDate() {
		String currentDate = "";

		SimpleDateFormat format1 = new SimpleDateFormat("yyyy'-'MM'-'dd");
		format1.setLenient(false);
		currentDate = format1.format(new Date());

		return currentDate;
	}
	/**
	 * �õ���ǰϵͳ����,��ʽ��yyyymmdd
	 * 
	 * @return String
	 */
	public static String getCurDate() {
		String currentDate = "";

		SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
		format1.setLenient(false);
		currentDate = format1.format(new Date());

		return currentDate;
	}

	/**
	 * �õ���ǰʱ�䣨HH:mm:ss��
	 * @param cal
	 * @return String
	 */
	public static synchronized String getCurTime() {
		String pattern = "HHmm";
		return getDateFormat(getCalendar(), pattern);
	}
	
	/**
	 * �õ���ǰʱ�䣨HHmm��
	 * @param cal
	 * @return String
	 */
	public static synchronized String getCurrentTime() {
		String pattern = "HH:mm:ss";
		return getDateFormat(getCalendar(), pattern);
	}
	
	/**
	 * @param cal
	 * @return String
	 */
	public static synchronized String getDateFormat(java.util.Calendar cal) {
		String pattern = "yyyy-MM-dd HH:mm:ss";
		return getDateFormat(cal, pattern);
	}

	/**
	 * @param date
	 * @return String
	 */
	public static synchronized String getDateFormat(java.util.Date date) {
		String pattern = "yyyy-MM-dd HH:mm:ss";
		return getDateFormat(date, pattern);
	}

	/**
	 * @param strDate
	 * @return java.util.Calendar
	 */
	public static synchronized Calendar parseCalendarFormat(String strDate) {
		String pattern = "yyyy-MM-dd HH:mm:ss";
		return parseCalendarFormat(strDate, pattern);
	}

	/**
	 * @param strDate
	 * @return java.util.Date
	 */
	public static synchronized Date parseDateFormat(String strDate) {
		String pattern = "yyyy-MM-dd HH:mm:ss";
		return parseDateFormat(strDate, pattern);
	}

	/**
	 * @param cal
	 * @param pattern
	 * @return String
	 */
	public static synchronized String getDateFormat(java.util.Calendar cal,
			String pattern) {
		return getDateFormat(cal.getTime(), pattern);
	}

	
	/**
	 * �õ���ǰʱ�䣨HHmm��
	 * @param cal
	 * @return String
	 */
	public static synchronized String getCurrentTime(String pattern) {
		return getDateFormat(getCalendar(), pattern);
	}

	/**
	 * @param date
	 * @param pattern
	 * @return String
	 */
	public static synchronized String getDateFormat(java.util.Date date,
			String pattern) {
		synchronized (sdf) {
			String str = null;
			sdf.applyPattern(pattern);
			str = sdf.format(date);
			return str;
		}
	}

	
	/**
	 * �÷������ַ�����ʽ��Ϊ��׼���ڸ�ʽ
	 * 
	 * @param String
	 * @return String
	 */
	public static String getFormatDate(String time) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date date;
		String strDate = "";
		try {
			date = df.parse(time);
			df.applyPattern("yyyy-MM-dd");
			strDate = df.format(date);
		} catch (ParseException e) {
		}

		return strDate;
	}

	/**
	 * �÷����õ��뵱���������ĸ�ʽ��ʱ��,
	 * OFFSET��ʾ�뵱������������SPLITDATE��ʾ���ڼ�ķָ�����SPLITTIME��ʾʱ���ķָ�����
	 * 
	 * @param int
	 *            offset
	 * @param String
	 *            splitdate
	 * @param String
	 *            splittime
	 * @return String
	 */
	public static String getPriorDay(int offset, String splitdate,
			String splittime) {
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar theday = Calendar.getInstance();
		theday.add(Calendar.DATE, offset);

		df.applyPattern("yyyy" + splitdate + "MM" + splitdate + "dd" + " "
				+ "HH" + splittime + "mm" + splittime + "ss");

		return df.format(theday.getTime());
	}
	
	public static synchronized Date parseDateDayFormat(String strDate) {
		String pattern = "yyyy-MM-dd";
		return parseDateFormat(strDate, pattern);
	}
	private static SimpleDateFormat sdf = new SimpleDateFormat();
	public static synchronized Date parseDateFormat(String strDate,
			String pattern) {
		synchronized (sdf) {
			Date date = null;
			sdf.applyPattern(pattern);
			try {
				date = sdf.parse(strDate);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return date;
		}
	}
	public static synchronized Calendar getCalendar() {
		return GregorianCalendar.getInstance();
	}
	/**
	 * @param strDate
	 * @param pattern
	 * @return java.util.Calendar
	 */
	public static synchronized Calendar parseCalendarFormat(String strDate,
			String pattern) {
		synchronized (sdf) {
			Calendar cal = null;
			sdf.applyPattern(pattern);
			try {
				sdf.parse(strDate);
				cal = sdf.getCalendar();
			} catch (Exception e) {
			}
			return cal;
		}
	}
}