/*
 * Created on 2006-5-15
 * TODO
 * author:gf
 */
package com.gd.service;

import com.gd.dao.UserDAO;
import com.gd.vo.User;

public interface Login {
	public abstract User queryUser(String username);
}
