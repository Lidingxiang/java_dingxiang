/*
 * Created on 2006-4-14
 * TODO
 * author:gf
 */
package com.gd.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.gd.dao.NewsDAO;
import com.gd.dao.NewsTypeDAO;
import com.gd.po.Newstype;
import com.gd.service.Release;
import com.gd.util.NewsUtil;
import com.gd.vo.News;
import com.gd.vo.NewsType;
import com.gd.vo.User;

public class ReleaseController extends SimpleFormController {
	private Logger logger = Logger.getLogger(this.getClass().getName());  
	private Release release;
  	public Release getRelease () {
    		return release;
  	}
 	public void setRelease (Release release) { 
    		this.release = release;
  	}
	public ModelAndView onSubmit(HttpServletRequest req, HttpServletResponse res,Object command, BindException errors) throws Exception { 
		 HttpSession session = req.getSession(true);
		 
		 NewsType newsType = new NewsType();
		 newsType.setId(Integer.parseInt(req.getParameter("newsType")));
		 News news = (News)command;
		 User user = (User)session.getAttribute("user");
		 news.setDate(NewsUtil.parseDateDayFormat(NewsUtil.getCurrentDate()));
		 news.setLnkUser(user);
		 news.setLnkNewsType(newsType);
		 getRelease().saveNews(news);
         Map model = errors.getModel(); 
		 Map mapNews = new HashMap();
		 List listNewsType = getNewsTypeDAO().queryNewsType();
		 for (int i = 0; listNewsType != null && i < listNewsType.size(); i++) {
			Newstype newsTypeTemp = (Newstype)listNewsType.get(i);
			List listNews = getNewsDAO().getNewsByType(newsTypeTemp.getId());
			mapNews.put(newsTypeTemp.getId(), listNews);
		 }
		 model.put("mapNews", mapNews);
		 model.put("listNewsType", listNewsType);
	     model.put("news", news); 
         return new ModelAndView(getSuccessView(), model); 
    } 
	private NewsDAO newsDAO;
  	public NewsDAO getNewsDAO () {
    		return newsDAO;
  	}
 	public void setNewsDAO (NewsDAO newsDAO) { 
    		this.newsDAO = newsDAO;
  	}
	
	private NewsTypeDAO newsTypeDAO;
  	public NewsTypeDAO getNewsTypeDAO () {
    		return newsTypeDAO;
  	}
 	public void setNewsTypeDAO (NewsTypeDAO newsTypeDAO) { 
    		this.newsTypeDAO = newsTypeDAO;
  	}
}
