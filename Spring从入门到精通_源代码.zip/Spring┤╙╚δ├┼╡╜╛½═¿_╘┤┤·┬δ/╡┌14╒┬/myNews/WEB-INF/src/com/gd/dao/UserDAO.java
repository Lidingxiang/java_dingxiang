package com.gd.dao;

import com.gd.po.*;

public interface UserDAO {
    public abstract void createUser(User user);
	public abstract void updateUser(User user);
	public abstract void deleteUser(User user);
    public abstract User queryUser(String name);
}
