/*
 * Created on 2006-1-12
 * TODO
 * author:gf
 */
package com.gc.impl;

public interface Hello {
	public String doSalutation();
}
