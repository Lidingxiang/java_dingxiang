/*
 * Created on 2006-5-15
 * TODO
 * author:gf
 */
package com.gc.service;

import com.gc.vo.User1;

public interface Regedit {
	public abstract String saveUser(User1 user);
}
