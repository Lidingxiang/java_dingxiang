package org.apache.jsp.WEB_002dINF.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.gd.util.*;
import com.gd.vo.*;
import com.gd.po.Newstype;
import com.gd.po.New;

public final class show_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=GBK");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"\r\n");
      out.write("\"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\">\r\n");
      out.write("<title>新闻发布的展示画面</title>\r\n");
      out.write("\r\n");
      out.write("<style type=\"text/css\">\r\n");
      out.write("<!--\r\n");
      out.write(".style1 {font-family: \"隶书\"}\r\n");
      out.write("-->\r\n");
      out.write("</style>\r\n");
      out.write("\r\n");
      out.write("</head>\r\n");
 
List listNewsType = (List)request.getAttribute("listNewsType");
Map mapNews = (Map)request.getAttribute("mapNews");

      out.write("\r\n");
      out.write("<body>\r\n");
      out.write("<table width=\"100%\" height=\"100%\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" >\r\n");
      out.write("  ");

  	   for (int i = 0; listNewsType != null && i < listNewsType.size(); i++) {  
  
      out.write("\r\n");
      out.write("  <tr height=\"100%\">\r\n");
      out.write("    <td height=\"20\"><strong>");
      out.print(((Newstype)listNewsType.get(i)).getType());
      out.write("</strong></td>\r\n");
      out.write("    <td><strong>");
      out.print(((Newstype)listNewsType.get(i + 1)).getType());
      out.write("</strong></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  <tr height=\"100%\">\r\n");
      out.write("    <td height=\"150\" width=\"50%\"><ol>\r\n");
      out.write("      ");

	       List newsHeads = (List)mapNews.get((((Newstype)listNewsType.get(i)).getId()));
      	   for (int j = 0; newsHeads != null && j < newsHeads.size(); j++) {  
  	  
      out.write("\r\n");
      out.write("      <li>");
      out.print(((New)newsHeads.get(j)).getHead() );
      out.write("</li>\r\n");
      out.write("      \t   ");
}
      out.write("\r\n");
      out.write("    </ol></td>\r\n");
      out.write("    <td><ol>\r\n");
      out.write("      ");

	  	   newsHeads = (List)mapNews.get((((Newstype)listNewsType.get(++i)).getId()));
      	   for (int j = 0; newsHeads != null && j < newsHeads.size(); j++) {  
  	  
      out.write("\r\n");
      out.write("      <li>");
      out.print(((New)newsHeads.get(j)).getHead() );
      out.write("</li>\r\n");
      out.write("    ");
}
      out.write("\r\n");
      out.write("    </ol></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  \r\n");
      out.write("  <tr height=\"100%\" style=\" border-top-width:1\">\r\n");
      out.write("    <td height=\"15\" style=\" border-top-width:1\"><div align=\"right\" class=\"style1\" >》更多内容</div></td>\r\n");
      out.write("    <td style=\" border-top-width:1\"><div align=\"right\" class=\"style1\" >》更多内容</div></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  ");
}
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
