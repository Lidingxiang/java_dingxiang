/*
 * Created on 2006-4-14
 * TODO
 * author:gf
 */
package com.gd.action;

import java.io.IOException;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.mvc.Controller;

import com.gd.dao.NewsDAO;
import com.gd.dao.NewsTypeDAO;
import com.gd.po.Newstype;
import com.gd.vo.User;

public class ShowController implements Controller {
	private Logger logger = Logger.getLogger(this.getClass().getName());  
	private String viewPage; 
	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse res) 
    throws ServletException, IOException {   
		Map model = new HashMap();
		Map mapNews = new HashMap();
		List listNewsType = getNewsTypeDAO().queryNewsType();
		for (int i = 0; listNewsType != null && i < listNewsType.size(); i++) {
			Newstype newsType = (Newstype)listNewsType.get(i);
			List listNews = getNewsDAO().getNewsByType(newsType.getId());
			mapNews.put(newsType.getId(), listNews);
		}
		model.put("mapNews", mapNews);
		model.put("listNewsType", listNewsType); 
        return new ModelAndView(getViewPage(), model); 
    }
	 //����ע��Ҫ���ص�ҳ��
    public void setViewPage(String viewPage) { 
       this.viewPage = viewPage; 
    } 
    //��ȡҪ���ص�ҳ��
    public String getViewPage() { 
       return viewPage; 
    } 
	private NewsDAO newsDAO;
  	public NewsDAO getNewsDAO () {
    		return newsDAO;
  	}
 	public void setNewsDAO (NewsDAO newsDAO) { 
    		this.newsDAO = newsDAO;
  	}
	
	private NewsTypeDAO newsTypeDAO;
  	public NewsTypeDAO getNewsTypeDAO () {
    		return newsTypeDAO;
  	}
 	public void setNewsTypeDAO (NewsTypeDAO newsTypeDAO) { 
    		this.newsTypeDAO = newsTypeDAO;
  	}
 
}
