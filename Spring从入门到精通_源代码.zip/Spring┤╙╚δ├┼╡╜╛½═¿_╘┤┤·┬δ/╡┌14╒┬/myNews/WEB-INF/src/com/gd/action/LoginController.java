/*
 * Created on 2006-4-14
 * TODO
 * author:gf
 */
package com.gd.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.gd.dao.NewsTypeDAO;
import com.gd.dao.UserDAO;
import com.gd.service.Login;
import com.gd.vo.User;

public class LoginController extends SimpleFormController {
	private Logger logger = Logger.getLogger(this.getClass().getName());  
    
	public ModelAndView onSubmit(HttpServletRequest req, HttpServletResponse res,Object command, BindException errors) throws Exception { 
		 HttpSession session = req.getSession(true);
		 User user = (User)command;
         Map model = errors.getModel(); 
	     model.put("user", user); 
		 if (user.validate(getLogin())) {
			 session.setAttribute("user", user);
			 List newsTypes = getNewsTypeDAO().queryNewsType();
			 model.put("newsTypes", newsTypes);
			 return new ModelAndView(getSuccessView(), model); 
		 } else {
			 return new ModelAndView(getFormView(), model); 
		 }  
    } 
	private NewsTypeDAO newsTypeDAO;
  	public NewsTypeDAO getNewsTypeDAO () {
    		return newsTypeDAO;
  	}
 	public void setNewsTypeDAO (NewsTypeDAO newsTypeDAO) { 
    		this.newsTypeDAO = newsTypeDAO;
  	}
	private Login login;
  	public Login getLogin () {
    		return login;
  	}
 	public void setLogin (Login login) { 
    		this.login = login;
  	}
}
