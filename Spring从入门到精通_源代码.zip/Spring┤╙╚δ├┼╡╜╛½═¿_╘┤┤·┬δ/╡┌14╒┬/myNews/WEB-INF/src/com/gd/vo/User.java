/*
 * Created on 2006-6-7
 * TODO
 * author:gf
 */
package com.gd.vo;

import com.gd.dao.UserDAO;
import com.gd.service.Login;

public class User {
    public String getMsg(){ 
return msg;
}
    public void setMsg(String msg){ 
this.msg = msg; 
}
    public String getPassword2(){ 
return password2; 
}
    public void setPassword2(String password2){ 
this.password2 = password2; 
}
    public String getPassword1(){
return password1; 
}
    public void setPassword1(String password1){ 
this.password1 = password1; 
}
    public String getUsername(){
return username; 
}
    public void setUsername(String username){ 
this.username = username; 
}
    public boolean validate(Login login) {
		User user = login.queryUser(getUsername());
		if (user != null && getPassword1().equals(user.getPassword1())) {
			return true;
		} else {
			return false;
		}	
    }
    private String msg;
    private String password2;
    private String password1;
    private String username;
	
	
}
