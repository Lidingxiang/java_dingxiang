package com.gd.po;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
public class UserauthorPK implements Serializable {

    /** identifier field */
    private String username;

    /** identifier field */
    private Integer power;

    /** full constructor */
    public UserauthorPK(String username, Integer power) {
        this.username = username;
        this.power = power;
    }

    /** default constructor */
    public UserauthorPK() {
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getPower() {
        return this.power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("username", getUsername())
            .append("power", getPower())
            .toString();
    }

    public boolean equals(Object other) {
        if ( (this == other ) ) return true;
        if ( !(other instanceof UserauthorPK) ) return false;
        UserauthorPK castOther = (UserauthorPK) other;
        return new EqualsBuilder()
            .append(this.getUsername(), castOther.getUsername())
            .append(this.getPower(), castOther.getPower())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getUsername())
            .append(getPower())
            .toHashCode();
    }

}
