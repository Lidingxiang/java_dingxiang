package com.gd.po;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
public class New implements Serializable {

    /** identifier field */
    private Integer id;

    /** persistent field */
    private String head;

    /** persistent field */
    private String content;

    /** persistent field */
    private Date issuedate;

    /** persistent field */
    private String issueuser;

    /** persistent field */
    private int newstype;

    /** full constructor */
    public New(String head, String content, Date issuedate, String issueuser, int newstype) {
        this.head = head;
        this.content = content;
        this.issuedate = issuedate;
        this.issueuser = issueuser;
        this.newstype = newstype;
    }

    /** default constructor */
    public New() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHead() {
        return this.head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getIssuedate() {
        return this.issuedate;
    }

    public void setIssuedate(Date issuedate) {
        this.issuedate = issuedate;
    }

    public String getIssueuser() {
        return this.issueuser;
    }

    public void setIssueuser(String issueuser) {
        this.issueuser = issueuser;
    }

    public int getNewstype() {
        return this.newstype;
    }

    public void setNewstype(int newstype) {
        this.newstype = newstype;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

}
