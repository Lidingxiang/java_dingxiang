/*
 * Created on 2006-5-15
 * TODO
 * author:gf
 */
package com.gd.service.impl;

import com.gd.dao.UserDAO;
import com.gd.service.Regedit;
import com.gd.vo.User;

public class RegeditImpl implements Regedit {
	private UserDAO userDao ;
	public void saveUser(User user) {
		com.gd.po.User userpo  = new com.gd.po.User();
		userpo.setUsername(user.getUsername());
		userpo.setPassword(user.getPassword1());
		userDao.createUser(userpo);
	}
	public void updateUser(User user) {
		com.gd.po.User userpo  = new com.gd.po.User();
		userpo.setUsername(user.getUsername());
		userpo.setPassword(user.getPassword1());
		userDao.updateUser(userpo);
	}
	public void deleteUser(User user) {
		com.gd.po.User userpo  = new com.gd.po.User();
		userpo.setUsername(user.getUsername());
		userpo.setPassword(user.getPassword1());
		userDao.deleteUser(userpo);
	}

	public User queryUser(String username) {
		User user = new User();
		user.setUsername(userDao.queryUser(username).getUsername());
		user.setPassword1(userDao.queryUser(username).getPassword());
		return user;
	}
	
	public void setUserDao (UserDAO userDao) {
		this.userDao = userDao;
	}
	public UserDAO getUserDao () {
		return this.userDao;
	}
}
