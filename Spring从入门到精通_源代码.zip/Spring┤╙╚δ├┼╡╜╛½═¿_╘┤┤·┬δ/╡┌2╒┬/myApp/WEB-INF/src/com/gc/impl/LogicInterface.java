/*
 * Created on 2006-3-3
 * TODO
 * author:gf
 */
package com.gc.impl;

public interface LogicInterface {
	public void doInsert(String name);
	public void doUpdate(String name);
	public void doDelete(String name);
}
