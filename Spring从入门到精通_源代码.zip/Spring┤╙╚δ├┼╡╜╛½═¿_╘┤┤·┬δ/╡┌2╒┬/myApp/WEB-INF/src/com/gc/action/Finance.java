/*
 * Created on 2006-3-1
 * TODO
 * author:gf
 */
package com.gc.action;

import com.gc.impl.FinanceInterface;

public class Finance implements FinanceInterface{
	public void doCheck(String name) { 		
		//���ʵ���س���    
	}
}
