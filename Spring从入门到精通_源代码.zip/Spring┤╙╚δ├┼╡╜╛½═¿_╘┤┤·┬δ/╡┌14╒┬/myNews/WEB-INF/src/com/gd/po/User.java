package com.gd.po;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;


/** @author Hibernate CodeGenerator */
public class User implements Serializable {

    /** identifier field */
    private String username;

    /** persistent field */
    private String password;

    /** full constructor */
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    /** default constructor */
    public User() {
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("username", getUsername())
            .toString();
    }

}
