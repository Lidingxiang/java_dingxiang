package com.gd.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;

import com.gd.dao.NewsDAO;
import com.gd.po.New;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class NewsDAOImpl extends HibernateDaoSupport implements NewsDAO {
	private Logger logger = Logger.getLogger(this.getClass().getName()); 
	
	private SessionFactory sessionFactory;
	private String hql = "from New n where n.id = ?";
	private String hqlByNewsType = "from New n where n.newstype = ?";
	
	public void createNews(New news) {
		this.getHibernateTemplate().save(news);
	}
	public void updateNews(New news) {
		this.getHibernateTemplate().update(news);
	}
	public void deleteNews(New news) {
		this.getHibernateTemplate().delete(news);
	}
	public New queryNews(Integer id){
		List newsList;
		if (this.getHibernateTemplate().find(hql, id) == null )
			newsList = new ArrayList();
		else 
			newsList = this.getHibernateTemplate().find(hql, id);
		return (New)newsList.get(0);
	}
	
	public List getNewsByType(Integer id){
		List newsList;
		if (this.getHibernateTemplate().find(hqlByNewsType, id) == null )
			newsList = new ArrayList();
		else 
			newsList = this.getHibernateTemplate().find(hqlByNewsType, id);
		return newsList;
	}
}