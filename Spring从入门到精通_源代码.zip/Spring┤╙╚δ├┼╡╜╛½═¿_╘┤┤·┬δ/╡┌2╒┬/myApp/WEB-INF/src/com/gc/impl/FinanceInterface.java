/*
 * Created on 2006-3-1
 * TODO
 * author:gf
 */
package com.gc.impl;

public interface FinanceInterface {
	public void doCheck(String name);
}
