package com.gd.dao;

import java.util.List;

import com.gd.po.*;

public interface NewsTypeDAO {
    public abstract void createNewsType(Newstype Newstype);
	public abstract void updateNewsType(Newstype Newstype);
	public abstract void deleteNewsType(Newstype Newstype);
    public abstract List queryNewsType();
}
