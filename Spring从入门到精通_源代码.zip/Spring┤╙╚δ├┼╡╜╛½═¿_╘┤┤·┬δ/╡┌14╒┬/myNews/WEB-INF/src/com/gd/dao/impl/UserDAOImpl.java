package com.gd.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;

import com.gd.dao.UserDAO;
import com.gd.po.User;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class UserDAOImpl extends HibernateDaoSupport implements UserDAO {
	private Logger logger = Logger.getLogger(this.getClass().getName()); 
	
	private SessionFactory sessionFactory;
	private String hql = "from User u where u.username = ?";
	
	public void createUser(User user) {
		this.getHibernateTemplate().save(user);
	}
	public void updateUser(User user) {
		this.getHibernateTemplate().update(user);
	}
	public void deleteUser(User user) {
		this.getHibernateTemplate().delete(user);
	}
	public User queryUser(String name){
		List userList;
		if (this.getHibernateTemplate().find(hql, name) == null ) {
			userList = new ArrayList();
			userList.add(new User());
		} else {
			userList = this.getHibernateTemplate().find(hql, name);
		}
		return (User)userList.get(0);
	}
}