/*
 * Created on 2006-5-15
 * TODO
 * author:gf
 */
package com.gd.service;

import com.gd.vo.News;
import com.gd.vo.User;

public interface Release {
	public abstract void saveNews(News news);
	public abstract void deleteNews(News news);
	public abstract void updateNews(News news);
}
