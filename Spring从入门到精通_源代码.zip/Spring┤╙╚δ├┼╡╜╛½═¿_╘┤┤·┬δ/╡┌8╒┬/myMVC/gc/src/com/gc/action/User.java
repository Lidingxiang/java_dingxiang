/*
 * Created on 2006-4-14
 * TODO
 * author:gf
 */
package com.gc.action;

public class User{
	private String username = null;
private String password = null;
private String password2 = null;
	public void setUsername (String username) {
		this.username = username;
	}
	public String getUsername () {
		return this.username;
	}
public void setPassword (String password) {
		this.password = password;
	}
	public String getPassword () {
		return this.password;
	}
public void setPassword2 (String password) {
		this.password2 = password;
	}
	public String getPassword2 () {
		return this.password2;
	}
}

